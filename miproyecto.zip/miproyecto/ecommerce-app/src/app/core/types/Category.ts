export type Category = {
  name: string;
  description: string;
  imageURL: string;
  parentCategory: string;
};
