export const environment = {
  production: false,
  BACK_URL: 'http://localhost:3000/api'
};