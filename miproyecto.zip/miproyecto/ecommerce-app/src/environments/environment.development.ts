export const environment = {
  BACK_URL: 'http://localhost:3000/api',
};
